import {
  DEFAULT_TWOTONE_COLOR,
  NZ_ICONS,
  NZ_ICONS_PATCH,
  NZ_ICONS_USED_BY_ZORRO,
  NZ_ICON_DEFAULT_TWOTONE_COLOR,
  NzIconDirective,
  NzIconModule,
  NzIconPatchService,
  NzIconService,
  provideNzIcons,
  provideNzIconsPatch
} from "./chunk-CYCHQH7S.js";
import "./chunk-2SJ2DHYL.js";
import "./chunk-BQ76GOFF.js";
import "./chunk-6TW7HUYK.js";
import "./chunk-BY3ZHUX4.js";
import "./chunk-UMYMDMRF.js";
import "./chunk-PAENDJ2C.js";
import "./chunk-ILDBYNRO.js";
import "./chunk-XMKOSNJN.js";
import "./chunk-GIJRZLUV.js";
import "./chunk-3OV72XIM.js";
export {
  DEFAULT_TWOTONE_COLOR,
  NZ_ICONS,
  NZ_ICONS_PATCH,
  NZ_ICONS_USED_BY_ZORRO,
  NZ_ICON_DEFAULT_TWOTONE_COLOR,
  NzIconDirective,
  NzIconModule,
  NzIconPatchService,
  NzIconService,
  provideNzIcons,
  provideNzIconsPatch
};
