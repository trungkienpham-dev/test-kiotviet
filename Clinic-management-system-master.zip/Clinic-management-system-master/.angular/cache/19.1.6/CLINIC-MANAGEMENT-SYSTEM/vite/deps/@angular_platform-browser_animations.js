import {
  BrowserAnimationsModule,
  InjectableAnimationEngine,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations
} from "./chunk-WTPAGEPE.js";
import "./chunk-JJWWU65N.js";
import "./chunk-PAENDJ2C.js";
import "./chunk-ILDBYNRO.js";
import "./chunk-XMKOSNJN.js";
import {
  ANIMATION_MODULE_TYPE
} from "./chunk-GIJRZLUV.js";
import "./chunk-3OV72XIM.js";
export {
  ANIMATION_MODULE_TYPE,
  BrowserAnimationsModule,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations,
  InjectableAnimationEngine as ɵInjectableAnimationEngine
};
