import {
  NZ_WAVE_GLOBAL_CONFIG,
  NZ_WAVE_GLOBAL_DEFAULT_CONFIG,
  NzWaveDirective,
  NzWaveModule,
  NzWaveRenderer,
  provideNzWave
} from "./chunk-NXDDOXIK.js";
import "./chunk-6TW7HUYK.js";
import "./chunk-WTPAGEPE.js";
import "./chunk-JJWWU65N.js";
import "./chunk-PAENDJ2C.js";
import "./chunk-ILDBYNRO.js";
import "./chunk-XMKOSNJN.js";
import "./chunk-GIJRZLUV.js";
import "./chunk-3OV72XIM.js";
export {
  NZ_WAVE_GLOBAL_CONFIG,
  NZ_WAVE_GLOBAL_DEFAULT_CONFIG,
  NzWaveDirective,
  NzWaveModule,
  NzWaveRenderer,
  provideNzWave
};
