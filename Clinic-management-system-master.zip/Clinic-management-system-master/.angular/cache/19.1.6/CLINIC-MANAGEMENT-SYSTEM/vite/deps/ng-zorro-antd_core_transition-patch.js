import {
  NzTransitionPatchDirective,
  NzTransitionPatchModule
} from "./chunk-GAOENXXN.js";
import "./chunk-GIJRZLUV.js";
import "./chunk-3OV72XIM.js";
export {
  NzTransitionPatchDirective as ɵNzTransitionPatchDirective,
  NzTransitionPatchModule as ɵNzTransitionPatchModule
};
