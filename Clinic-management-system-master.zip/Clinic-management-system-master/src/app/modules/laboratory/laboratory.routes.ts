import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {
    // path: '',
    // component: 
  }
];

export const LaboratoryRoutes = RouterModule.forChild(routes);