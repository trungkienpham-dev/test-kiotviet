import { Routes, RouterModule } from '@angular/router';
import { PatientWaitingListComponent } from './patient-waiting/patient-waiting-list/patient-waiting-list.component';
import { ExaminationDetailComponent } from './examination-detail/examination-detail.component';

const routes: Routes = [
  {
    path: 'patient-waiting-list',
    component: PatientWaitingListComponent
  },
  {
    path: 'examination-detail/:id',
    component: ExaminationDetailComponent
  },
];

export const ExaminationRoutes = RouterModule.forChild(routes);