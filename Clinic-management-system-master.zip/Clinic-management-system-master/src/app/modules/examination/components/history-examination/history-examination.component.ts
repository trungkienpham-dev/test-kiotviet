import { Component } from '@angular/core';
import { sharedModule } from '../../../../shared/shared.module';

@Component({
  selector: 'app-history-examination',
  imports: [sharedModule],
  templateUrl: './history-examination.component.html',
  styles: ``
})
export class HistoryExaminationComponent {
  records = Array(15).fill({ code: 'HS002', date: '20/11/2021' });
  services = [
    {
      stt: 1,
      soPhieu: '1120',
      maDV: 'KB01',
      tenDV: 'Khám tổng thể',
      soLuong: 1,
      phongThucHien: 'P.103-Phòng khám',
      khoaChiDinh: 'Tiếp đón',
      bacSi: 'BS. Hồ Trọng Đại',
      thanhTien: '81.000'
    },
    {
      stt: 2,
      soPhieu: '1120',
      maDV: 'KB02',
      tenDV: 'Khám nội',
      soLuong: 1,
      phongThucHien: 'P.101-Phòng khám nội',
      khoaChiDinh: 'Khám bệnh',
      bacSi: 'BS. Hồ Thị Loan',
      thanhTien: '81.000'
    },
    {
      stt: 3,
      soPhieu: 'XN01',
      maDV: 'XN01',
      tenDV: 'Ure',
      soLuong: 1,
      phongThucHien: 'P.102-Phòng xét nghiệm',
      khoaChiDinh: 'Khám bệnh',
      bacSi: 'BS. Hồ Trung Hiếu',
      thanhTien: '81.000'
    }
  ]
}
