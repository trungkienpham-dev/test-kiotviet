import { Component } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { sharedModule } from '../../../../shared/shared.module';
import { InputComponent } from '../../../../shared/controls/input/input.component';

@Component({
  selector: 'app-patient-update',
  imports: [sharedModule, InputComponent, RouterModule],
  templateUrl: './patient-update.component.html',
  styleUrl: './patient-update.component.scss',
})
export class PatientUpdateComponent {
  constructor(public router: Router) {}
}
