
// import common
import { Component, OnInit } from '@angular/core';
import { sharedModule } from '../../../../shared/shared.module';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { formatData } from '../../../../core/services/formatData.service';
// import models
import { ColumnConfig } from '../../../../shared/models/column-config';
// import data dummy
import { servicesReceived } from '../../../../dataDummy/serviesReceived';
import { patients } from '../../../../dataDummy/patient';
// import Component
import { ServiceIndicationDialogComponent } from "../../../../shared/components/service-indication-dialog/service-indication-dialog.component";
import { HistoryExaminationComponent } from "../../components/history-examination/history-examination.component";
import { TableComponent } from "../../../../shared/components/table/table.component";
import { ConfirmDialogComponent } from '../../../../shared/components/confirm-dialog/confirm-dialog.component';

@Component({
  selector: 'app-patient-detail',
  imports: [sharedModule, RouterModule, ServiceIndicationDialogComponent, HistoryExaminationComponent, TableComponent, ConfirmDialogComponent],
  templateUrl: './patient-detail.component.html',
  styleUrl: './patient-detail.component.scss',
})
export class PatientDetailComponent implements OnInit {
  isShowServiceIndicationDialog: boolean = false;
  isShowCancelReceivedDialog: boolean = false;
  isShowPaymentConfirmDialog: boolean = false;
  servicesReceived: any[] = [];
  patientInfo: any;

  servicesColumnConfig: ColumnConfig[] = [
    { key: 'soPhieu', header: 'Số phiếu' },
    { key: 'maDV', header: 'Mã DV' },
    { key: 'tenDV', header: 'Tên dịch vụ' },
    { key: 'soLuong', header: 'Số lượng' },
    { key: 'phongThucHien', header: 'Phòng thực hiện' },
    { key: 'khoaChiDinh', header: 'Khoa chỉ định' },
    { key: 'bacSi', header: 'Bác sĩ' },
    { key: 'thanhTien', header: 'Thành tiền' },
    { key: 'action', header: 'Hành động' },
  ]
 
  constructor(
    public router: Router,
    public formatData: formatData,
    private route: ActivatedRoute,
  ) {}

  ngOnInit(): void {
    this.patientInfo = this.getPatientInfobyId(this.route.snapshot.params['id']);
    this.servicesReceived = this.patientInfo.status !== "Chờ tiếp đón" ? servicesReceived : [];

  }

  getPatientInfobyId(id: any) {
    return patients.find((p: any) => p.id == id);
  }

  onClickOK() {
    this.servicesReceived = [];
    this.patientInfo.status = 'Chờ tiếp đón';
    this.isShowCancelReceivedDialog = false;
  }

  onClickOKPaymentDialog() {
    this.isShowPaymentConfirmDialog = false;
  }

  onOkServiceIndication() {}
}