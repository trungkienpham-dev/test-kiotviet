import { Routes, RouterModule } from '@angular/router';
import { PatientListComponent } from './patient/patient-list/patient-list.component';
import { PatientCreateComponent } from './patient/patient-create/patient-create.component';
import { PatientDetailComponent } from './patient/patient-detail/patient-detail.component';
import { PatientUpdateComponent } from './patient/patient-update/patient-update.component';

const routes: Routes = [
  {
    path: 'patient-list',
    component: PatientListComponent
  },
  {
    path: 'patient-create',
    component: PatientCreateComponent
  },
  {
    path: 'patient-detail/:id',
    component: PatientDetailComponent
  },
  {
    path: 'patient-update/:id',
    component: PatientUpdateComponent
  },
];

export const ReceptionRoutes = RouterModule.forChild(routes);