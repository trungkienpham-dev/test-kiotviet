import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReceptionRoutes } from './reception.routes';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    ReceptionRoutes
  ]
})
export class ReceptionModule { }
