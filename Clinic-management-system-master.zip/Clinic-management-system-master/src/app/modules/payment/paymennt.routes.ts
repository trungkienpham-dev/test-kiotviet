import { Routes, RouterModule } from '@angular/router';
import { PaymentListComponent } from './payment-list/payment-list.component';
import { PaymentDetailComponent } from './payment-detail/payment-detail.component';

const routes: Routes = [
  {
    path: 'payment-list',
    component: PaymentListComponent
  },
  {
    path: 'payment-detail/:id',
    component: PaymentDetailComponent
  },
];

export const PaymentRoutes = RouterModule.forChild(routes);