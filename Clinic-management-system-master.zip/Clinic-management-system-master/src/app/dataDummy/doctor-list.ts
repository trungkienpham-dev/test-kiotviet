export const DOCTOR_LIST = [
  { id: 1, name: 'GS BS. Tôn Thất Tùng' },
  { id: 2, name: 'BS. Hồ Đắc Di' },
  { id: 3, name: 'BS. Đặng Văn Ngữ' },
  { id: 4, name: 'BS. Trần Duy Hưng' },
  { id: 5, name: 'PSG BS. Tôn Thất Bách' },
  { id: 6, name: 'BS. Nguyễn Hữu Ước' },
  { id: 7, name: 'BS. Phạm Gia Khải' },
  { id: 8, name: 'BS. Vũ Quốc Huy' },
  { id: 9, name: 'BS. Lê Hữu Nghĩa' },
  { id: 10, name: 'BS. Trương Hữu Khanh' },
];
