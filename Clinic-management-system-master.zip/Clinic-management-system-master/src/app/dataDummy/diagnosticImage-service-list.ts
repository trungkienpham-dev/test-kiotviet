export const DIAGNOSTICIMAGE_SERVICE_LIST = [
    {
        id: 1,
        name: 'Siêu âm đầu dò âm đạo'
    },
    {
        id: 2,  
        name: 'Siêu âm 2D'
    },
    {
        id: 3,
        name: 'Siêu âm 4D'
    },
    {
        id: 4,  
        name: 'Siêu âm ổ bụng tổng quát'
    },
    {
        id: 5,
        name: 'Siêu âm tuyến giáp'
    },
    {
        id: 6,  
        name: 'Siêu âm khớp cơ, mô mềm'
    },
    {
        id: 7,
        name: 'Chụp X quang KTS tim phổi thẳng'
    },
    {
        id: 8,  
        name: 'Điện tim'
    },
    {
        id: 9,
        name: 'Chụp X quang KTS khác'
    },
    {
        id: 10,  
        name: 'Nội soi tai'
    },
    {
        id: 1,
        name: 'Nội soi họng'
    },
    {
        id: 12,  
        name: 'Nội soi mũi'
    }
];