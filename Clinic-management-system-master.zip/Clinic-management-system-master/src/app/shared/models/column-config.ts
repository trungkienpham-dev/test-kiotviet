export interface ColumnConfig {
  key: string;
  header: string;
  nzWidth?: string;     //thay đổi width
  isShowCol?: boolean;  //có hiển thị cột trên table hay không?
  pipe?: string;
  nzAlign?: any;
  nzAligntitle?: any;
}
