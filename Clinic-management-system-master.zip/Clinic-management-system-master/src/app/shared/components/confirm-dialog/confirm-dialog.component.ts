import { Component, EventEmitter, Input, Output } from '@angular/core';
import { sharedModule } from '../../shared.module';

@Component({
  selector: 'app-confirm-dialog',
  imports: [sharedModule],
  templateUrl: './confirm-dialog.component.html',
  styles: ``
})
export class ConfirmDialogComponent {
  @Input() isOpenModal: boolean = false;
  @Input() title: string = '';
  @Input() message: string = '';
  @Output() onConfirm = new EventEmitter<void>();
  @Output() onCancel = new EventEmitter<void>();


  onOk() {
    this.onConfirm.emit();
    this.isOpenModal = false;
  }

  onClickCancel() {
    this.onConfirm.emit();
    this.isOpenModal = false;
  }
  constructor() {}
}
