import { Component, OnInit } from '@angular/core';
import { sharedModule } from '../../shared.module';
import { InputComponent } from '../../controls/input/input.component';
import { EXAMINATION_LIST } from '../../../dataDummy/examination-list';
import { LABORATORY_SERVICE_LIST } from '../../../dataDummy/laboratory-service-list';
import { DIAGNOSTICIMAGE_SERVICE_LIST } from '../../../dataDummy/diagnosticImage-service-list';
import { SCISSOR_SERVICE_LIST } from '../../../dataDummy/scissor-service-list';
import { DOCTOR_LIST } from '../../../dataDummy/doctor-list';

@Component({
  selector: 'app-service-indication-dialog',
  imports: [sharedModule, InputComponent],
  templateUrl: './service-indication-dialog.component.html',
  styles: ``
})
export class ServiceIndicationDialogComponent implements OnInit{
  serviceGroups: {id: number, name: string}[] = [
    { id: 1, name: 'Khám bệnh' },
    { id: 2, name: 'Xét nghiệm' },
    { id: 3, name: 'CĐHA' },
    { id: 4, name: 'Xét nghiệm' }
  ];
  serviceGroupSelectedId: number = 1;

  services: {id: number, name: string}[] = EXAMINATION_LIST;
  serviceSelectedId: number = EXAMINATION_LIST[0].id;

  doctors = DOCTOR_LIST;
  doctorSelectedId: number = DOCTOR_LIST[0].id;

  constructor() {}
  ngOnInit(): void {}

  serviceGroupsChange() {
    switch (this.serviceGroupSelectedId) {
      case 1:
        this.services = EXAMINATION_LIST;
        this.serviceSelectedId = EXAMINATION_LIST[0].id;
        break;
      case 2:
        this.services = LABORATORY_SERVICE_LIST;
        this.serviceSelectedId = LABORATORY_SERVICE_LIST[0].id;
        break;
      case 3:
        this.services = DIAGNOSTICIMAGE_SERVICE_LIST;
        this.serviceSelectedId = DIAGNOSTICIMAGE_SERVICE_LIST[0].id;
        break;
      case 4:
        this.services = SCISSOR_SERVICE_LIST;
        this.serviceSelectedId = SCISSOR_SERVICE_LIST[0].id;
        break;
      default:
        this.services = EXAMINATION_LIST;
        break;
    }
  }
}
