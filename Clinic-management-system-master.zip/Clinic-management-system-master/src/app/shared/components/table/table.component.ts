import { Component, EventEmitter, Input, Output } from '@angular/core';
import { sharedModule } from '../../shared.module';
import { ColumnConfig } from '../../models/column-config';
import { RouterModule } from '@angular/router';
import { formatData } from '../../../core/services/formatData.service';
import { InputComponent } from "../../controls/input/input.component";

@Component({
  selector: 'app-table',
  imports: [
    sharedModule,
    RouterModule,
    InputComponent
],
  templateUrl: './table.component.html',
  styleUrl: './table.component.scss',
})

export class TableComponent {
  @Input() columns: ColumnConfig[] = [];  // Cấu hình cột
  @Input() data: any[] = [];
  @Input() pageSize: number = 5;
  @Input() btnActions: { name: string }[] = [{ name: 'Chi tiết' }];
  @Input() isShowFilter = true; //Hiển thị ô tìm kiếm ở mỗi cột hay không?
  @Input() nzPageIndex: number = 1;
  @Input() nzTotal: number = 0;
  @Input() heightTable: string = '400px';
  @Input() isShowCheckbox: boolean = false;
  @Output() dbClickItem = new EventEmitter<any>();
  @Output() clickBtnAction = new EventEmitter<any>();

  listOfCurrentPageData: readonly any[] = [];
  indeterminate = false;
  checked: boolean = false;

  constructor(public formatData: formatData) {}

  onCurrentPageDataChange($event: any): void {
    this.listOfCurrentPageData = $event;
  }

  onDbClickItem(item: any) {
    this.dbClickItem.next(item);
  }

  onClickBtnAction(data: any, btn: any) {
    this.clickBtnAction.next({
      data: data,
      action: btn.name,
    });
  }

  onAllChecked(e: any): void {
  }

  onItemChecked(id: any, event: boolean): void {
  }
}
