import { NgModule } from "@angular/core";
import { NzDropDownModule } from "ng-zorro-antd/dropdown";
import { NzIconModule } from "ng-zorro-antd/icon";
import { NzLayoutModule } from "ng-zorro-antd/layout";
import { NzMenuModule } from "ng-zorro-antd/menu";
import { NzTableModule } from "ng-zorro-antd/table";
import { NzInputModule } from 'ng-zorro-antd/input';
import { NzPaginationModule } from 'ng-zorro-antd/pagination';
import { NzModalModule } from "ng-zorro-antd/modal";
import { NzButtonModule } from 'ng-zorro-antd/button'
import { NzCheckboxModule } from 'ng-zorro-antd/checkbox';
import { NzTagModule } from "ng-zorro-antd/tag";
import { NzGridModule } from "ng-zorro-antd/grid";
import { NzUploadModule } from "ng-zorro-antd/upload";
import { NzBreadCrumbModule } from "ng-zorro-antd/breadcrumb";
import { NzPageHeaderModule } from "ng-zorro-antd/page-header";
import { NzTabsModule } from "ng-zorro-antd/tabs";
import { NzBadgeModule } from "ng-zorro-antd/badge";
import { NzAvatarModule } from "ng-zorro-antd/avatar";
import { NzSpaceModule } from "ng-zorro-antd/space";
import { NzDescriptionsModule } from "ng-zorro-antd/descriptions";
import { NzCardModule } from "ng-zorro-antd/card";
import { NzCollapseModule } from "ng-zorro-antd/collapse";
import { NzSelectModule } from "ng-zorro-antd/select";
import { NzFormModule } from "ng-zorro-antd/form";
import { NzListModule } from "ng-zorro-antd/list";
import { NzInputNumberModule } from "ng-zorro-antd/input-number";
import { NzStepsModule } from "ng-zorro-antd/steps";

@NgModule({
    exports: [
        NzLayoutModule, 
        NzMenuModule, 
        NzIconModule,
        NzTableModule,
        NzDropDownModule,
        NzInputModule,
        NzPaginationModule,
        NzIconModule,
        NzModalModule,
        NzButtonModule,
        NzCheckboxModule,
        NzTagModule,
        NzGridModule,
        NzUploadModule,
        NzBreadCrumbModule,
        NzPageHeaderModule,
        NzTabsModule,
        NzBadgeModule,
        NzAvatarModule,
        NzSpaceModule,
        NzDescriptionsModule,
        NzCardModule,
        NzCollapseModule,
        NzSelectModule,
        NzFormModule,
        NzListModule,
        NzInputNumberModule,
        NzStepsModule
    ]
})
export class ZorroAntdModule { }