import {
  NZ_SPACE_COMPACT_ITEMS,
  NZ_SPACE_COMPACT_ITEM_TYPE,
  NZ_SPACE_COMPACT_SIZE,
  NzSpaceCompactComponent,
  NzSpaceCompactItemDirective,
  NzSpaceComponent,
  NzSpaceItemDirective,
  NzSpaceModule
} from "./chunk-QJYOBJGL.js";
import "./chunk-YUXRL54L.js";
import "./chunk-A6EU753X.js";
import "./chunk-BY3ZHUX4.js";
import "./chunk-UMYMDMRF.js";
import "./chunk-3ERJTLUB.js";
import "./chunk-XMKOSNJN.js";
import "./chunk-GIJRZLUV.js";
import "./chunk-3OV72XIM.js";
export {
  NZ_SPACE_COMPACT_ITEMS,
  NZ_SPACE_COMPACT_ITEM_TYPE,
  NZ_SPACE_COMPACT_SIZE,
  NzSpaceCompactComponent,
  NzSpaceCompactItemDirective,
  NzSpaceComponent,
  NzSpaceItemDirective,
  NzSpaceModule
};
