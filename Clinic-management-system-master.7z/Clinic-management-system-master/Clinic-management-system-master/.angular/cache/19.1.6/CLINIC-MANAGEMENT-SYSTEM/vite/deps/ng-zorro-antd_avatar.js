import {
  NzAvatarComponent,
  NzAvatarGroupComponent,
  NzAvatarModule
} from "./chunk-N6QMRY4T.js";
import "./chunk-CYCHQH7S.js";
import "./chunk-2SJ2DHYL.js";
import "./chunk-BQ76GOFF.js";
import "./chunk-6TW7HUYK.js";
import "./chunk-BY3ZHUX4.js";
import "./chunk-UMYMDMRF.js";
import "./chunk-PAENDJ2C.js";
import "./chunk-ILDBYNRO.js";
import "./chunk-XMKOSNJN.js";
import "./chunk-GIJRZLUV.js";
import "./chunk-3OV72XIM.js";
export {
  NzAvatarComponent,
  NzAvatarGroupComponent,
  NzAvatarModule
};
