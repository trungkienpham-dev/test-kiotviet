import { Component, OnInit } from '@angular/core';
import { Router, RouterModule, RouterOutlet } from '@angular/router';
import { MenuItem, MENUITEMS } from './sidebar-menu';
import { sharedModule } from '../../shared/shared.module';

@Component({
  selector: 'app-content-layout',
  standalone: true,
  imports: [sharedModule, RouterOutlet, RouterModule],
  templateUrl: './content-layout.component.html',
  styleUrl: './content-layout.component.scss',
})
export class ContentLayoutComponent {
  isCollapsed = false;
  menuItems: MenuItem[] = MENUITEMS;
  constructor(public router: Router){}

  isSelected(item: any): boolean {
    return this.router.url.includes(item.path);
  }
}
