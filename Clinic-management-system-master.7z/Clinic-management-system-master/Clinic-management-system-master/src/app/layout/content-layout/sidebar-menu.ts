export interface MenuItem {
  name: string;
  icon: string;
  path: string;
  children: MenuItem[];
}

export const MENUITEMS: MenuItem[] = [
  {
    name: 'Trang chủ',
    icon: 'home',
    path: '/home',
    children: [],
  },
  {
    name: 'Tiếp đón',
    icon: 'desktop',
    path: '/reception/patient-list',
    children: [],
  },
  {
    name: 'Thanh toán',
    icon: 'wallet',
    path: '/payment/payment-list',
    children: [],
  },
  {
    name: 'Khám chữa bệnh',
    icon: 'heart',
    path: '/examination/patient-waiting-list',
    children: [],
  },
  {
    name: 'Xét nghiệm',
    icon: 'experiment',
    path: '/laboratory',
    children: [],
  },
  {
    name: 'CĐHA',
    icon: 'file-image',
    path: '/diagnostic-image',
    children: [],
  },
  {
    name: 'Thủ thuật',
    icon: 'scissor',
    path: '/scissor',
    children: [],
  },
  {
    name: 'Danh mục',
    icon: 'menu',
    path: '/menu',
    children: [],
  },
];
