import { Component, EventEmitter, Input, Output } from '@angular/core';
import { sharedModule } from '../../shared.module';
import { Router } from '@angular/router';

@Component({
  selector: 'app-button',
  imports: [sharedModule],
  templateUrl: './button.component.html',
  styles: ``,
})
export class InputComponent {
  @Input() navigateUrl = '';

  constructor(public router: Router) {}
}
