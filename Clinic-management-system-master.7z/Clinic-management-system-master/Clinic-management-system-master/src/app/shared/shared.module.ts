// shared-imports.ts
import { CommonModule } from "@angular/common";
import { ZorroAntdModule } from "./zorro-antd.module";
import { FormsModule } from "@angular/forms";

export const sharedModule = [
  CommonModule,
  FormsModule,
  ZorroAntdModule
];
