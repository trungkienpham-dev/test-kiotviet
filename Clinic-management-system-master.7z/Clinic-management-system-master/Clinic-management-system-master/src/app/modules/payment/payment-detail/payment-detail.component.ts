import { Component, OnInit } from '@angular/core';
import { sharedModule } from '../../../shared/shared.module';
import { Router } from '@angular/router';
import { InputComponent } from '../../../shared/controls/input/input.component';
import { TableComponent } from '../../../shared/components/table/table.component';
import { ColumnConfig } from '../../../shared/models/column-config';
import { servicesReceived } from '../../../dataDummy/serviesReceived';
import { HistoryExaminationComponent } from "../components/history-examination/history-examination.component";

@Component({
  selector: 'app-payment-detail',
  imports: [sharedModule, InputComponent, TableComponent, HistoryExaminationComponent],
  templateUrl: './payment-detail.component.html',
  styleUrl: './payment-detail.component.scss'
})
export class PaymentDetailComponent implements OnInit {
  servicesColumnConfig: ColumnConfig[] = [
    { key: 'soPhieu', header: 'Số phiếu' },
    { key: 'maDV', header: 'Mã DV' },
    { key: 'tenDV', header: 'Tên dịch vụ' },
    { key: 'soLuong', header: 'Số lượng' },
    { key: 'phongThucHien', header: 'Phòng thực hiện' },
    { key: 'khoaChiDinh', header: 'Khoa chỉ định' },
    { key: 'bacSi', header: 'Bác sĩ' },
    { key: 'thanhTien', header: 'Thành tiền' },
    { key: 'action', header: 'Hành động' },
  ]
  servicesReceived: any[] = [];
  isShowHistoryDialog: boolean = false

  constructor(
    public router: Router
  ) {}

  ngOnInit(): void {
    this.servicesReceived = servicesReceived;
  }
}