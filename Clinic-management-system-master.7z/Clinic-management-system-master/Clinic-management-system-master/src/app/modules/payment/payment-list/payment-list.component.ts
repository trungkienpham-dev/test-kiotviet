import { Component } from '@angular/core';
import { sharedModule } from '../../../shared/shared.module';
import { TableComponent } from '../../../shared/components/table/table.component';
import { ColumnConfig } from '../../../shared/models/column-config';
import { Router } from '@angular/router';
import { patients } from '../../../dataDummy/patient';

@Component({
  selector: 'app-payment-list',
  imports: [sharedModule, TableComponent],
  templateUrl: './payment-list.component.html',
  styleUrl: './payment-list.component.scss',
})
export class PaymentListComponent {
  columnConfig: ColumnConfig[] = [
    {
      key: 'profileId',
      header: 'Mã hồ sơ',
      isShowCol: false,
      nzWidth: '150px',
    },
    {
      key: 'patientId',
      header: 'Mã bệnh nhân',
      isShowCol: false,
      nzWidth: '150px',
    },
    {
      key: 'fullName',
      header: 'Họ và tên',
      isShowCol: true,
      pipe: 'properName',
      nzWidth: '250px',
    },
    {
      key: 'regisDate',
      header: 'Ngày đăng ký',
      isShowCol: false,
      pipe: 'date',
      nzWidth: '150px',
    },
    {
      key: 'phoneNumber',
      header: 'Số điện thoại',
      isShowCol: false,
      nzWidth: '150px',
    },
    {
      key: 'birthday',
      header: 'Ngày sinh',
      isShowCol: true,
      pipe: 'date',
      nzWidth: '120px',
    },
    {
      key: 'age',
      header: 'Tuổi',
      isShowCol: true,
      nzWidth: '50px',
      nzAlign: 'center',
      nzAligntitle: 'center',
    },
    {
      key: 'gender',
      header: 'Giới tính',
      isShowCol: true,
      pipe: 'gender',
      nzAlign: 'center',
      nzAligntitle: 'center',
      nzWidth: '90px',
    },
    {
      key: 'address',
      header: 'Địa chỉ',
      isShowCol: true,
      pipe: 'properName',
      nzWidth: '300px',
    },
    {
      key: 'reason',
      header: 'Lý do đến khám',
      isShowCol: true,
      nzWidth: '300px',
    },
    {
      key: 'status',
      header: 'Trạng thái',
      isShowCol: true,
      pipe: 'tagColor',
      nzAlign: 'center',
      nzAligntitle: 'center',
      nzWidth: '150px',
    },
  ];
  data: any[] = [];
  columns: ColumnConfig[] = [];
  
  constructor(
    public router: Router
  ) {}

  ngOnInit(): void {
    this.data = patients.filter((p: any) => p.status == 'Chờ thanh toán');
    this.columns = this.columnConfig.filter((c) => c.isShowCol);
  }

  onDbClickItem(e: any) {
    console.log(e)
    this.router.navigate([`/payment/payment-detail/${e.id}`])
  }
}