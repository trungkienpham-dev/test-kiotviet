import { Component } from '@angular/core';
import { sharedModule } from '../../../../shared/shared.module';
import { InputComponent } from "../../../../shared/controls/input/input.component";
import { Router, RouterModule } from '@angular/router';

@Component({
  selector: 'app-patient-create',
  imports: [
    sharedModule,
    InputComponent,
    RouterModule
],
  templateUrl: './patient-create.component.html',
  styleUrl: './patient-create.component.scss'
})
export class PatientCreateComponent {
  constructor(
    public router: Router
  ) {}
}
