import { Component } from '@angular/core';
import { sharedModule } from '../../../../shared/shared.module';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-appointment',
  imports: [sharedModule, RouterModule],
  templateUrl: './appointment.component.html',
  styleUrl: './appointment.component.scss'
})
export class AppointmentComponent {
  selectedDoctor: number = 0;
  doctors: any[] = [
    { id: 1, name: 'Nguyễn Văn A' },
    { id: 2, name: 'Nguyễn Văn B' },
  ];

  selectedRoom: number = 0;
  rooms: any[] = [
    { id: 1, name: 'P201' },
    { id: 2, name: 'P202' },
    { id: 2, name: 'P301' },
    { id: 2, name: 'P302' },
  ];

  selectedService: number[] = [0];
  services: any[] = [
    { id: 1, name: 'Khám phụ khoa định kỳ' },
    { id: 2, name: 'Siêu âm thai 2D' },
    { id: 3, name: 'Siêu âm thai 3D' },
    { id: 4, name: 'Siêu âm thai 4D' },
    { id: 5, name: 'Xét nghiệm máu' },
    { id: 6, name: 'Xét nghiệm nước tiểu' },
    { id: 7, name: 'Siêu âm tử cung – buồng trứng' },
    { id: 8, name: 'Tư vấn sức khỏe sinh sản trước khi mang thai' },

  ];
}
