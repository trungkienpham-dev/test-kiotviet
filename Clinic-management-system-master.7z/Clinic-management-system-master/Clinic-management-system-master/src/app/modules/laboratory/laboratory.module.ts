import { NgModule } from '@angular/core';
import { LaboratoryRoutes } from './laboratory.routes';

@NgModule({
  declarations: [],
  imports: [
    LaboratoryRoutes
  ]
})
export class LaboratoryModule { }