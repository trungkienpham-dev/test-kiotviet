import { Component } from '@angular/core';
import { sharedModule } from '../../../../shared/shared.module';

@Component({
  selector: 'app-patient-journey',
  imports: [sharedModule],
  templateUrl: './patient-journey.component.html',
  styles: ``
})
export class PatientJourneyComponent {

}
