import { Component } from '@angular/core';
import { sharedModule } from '../../../../shared/shared.module';
import { TableComponent } from '../../../../shared/components/table/table.component';
import { ColumnConfig } from '../../../../shared/models/column-config';
import { Router } from '@angular/router';
import { patients } from '../../../../dataDummy/patient';

@Component({
  selector: 'app-patient-waiting-list',
  imports: [sharedModule, TableComponent],
  templateUrl: './patient-waiting-list.component.html',
  styleUrl: './patient-waiting-list.component.scss',
})
export class PatientWaitingListComponent {
  columnConfig: ColumnConfig[] = [
    {
      key: 'profileId',
      header: 'Mã hồ sơ',
      isShowCol: false,
      nzWidth: '150px',
    },
    {
      key: 'patientId',
      header: 'Mã bệnh nhân',
      isShowCol: false,
      nzWidth: '150px',
    },
    {
      key: 'fullName',
      header: 'Họ và tên',
      isShowCol: true,
      pipe: 'properName',
      nzWidth: '250px',
    },
    {
      key: 'regisDate',
      header: 'Ngày đăng ký',
      isShowCol: false,
      pipe: 'date',
      nzWidth: '150px',
    },
    {
      key: 'phoneNumber',
      header: 'Số điện thoại',
      isShowCol: false,
      nzWidth: '150px',
    },
    {
      key: 'birthday',
      header: 'Ngày sinh',
      isShowCol: true,
      pipe: 'date',
      nzWidth: '120px',
    },
    {
      key: 'age',
      header: 'Tuổi',
      isShowCol: true,
      nzWidth: '50px',
      nzAlign: 'center',
      nzAligntitle: 'center',
    },
    {
      key: 'gender',
      header: 'Giới tính',
      isShowCol: true,
      pipe: 'gender',
      nzAlign: 'center',
      nzAligntitle: 'center',
      nzWidth: '90px',
    },
    {
      key: 'address',
      header: 'Địa chỉ',
      isShowCol: true,
      pipe: 'properName',
      nzWidth: '300px',
    },
    {
      key: 'reason',
      header: 'Lý do đến khám',
      isShowCol: true,
      nzWidth: '300px',
    },
    {
      key: 'status',
      header: 'Trạng thái',
      isShowCol: true,
      pipe: 'tagColor',
      nzAlign: 'center',
      nzAligntitle: 'center',
      nzWidth: '150px',
    },
  ];

  data: any[] = [];
  columns: ColumnConfig[] = [];
  btnActions: { name: string }[] = [{ name: 'Tiếp nhận' }];

  selectedRoom: number = 1;
  rooms: any[] = [
    { id: 1, name: 'Tất cả' },
    { id: 2, name: 'P202' },
    { id: 3, name: 'P301' },
    { id: 4, name: 'P302' },
  ];
  constructor(public router: Router) {}

  ngOnInit(): void {
    this.data = patients.filter((p: any) => p.status == 'Chờ khám');
    this.columns = this.columnConfig.filter((c) => c.isShowCol);
  }

  onDbClickItem(event: any) {
    this.router.navigate([`/examination/examination-detail/${event.id}`]);
  }
}
