import { Component, OnInit } from '@angular/core';
import { sharedModule } from '../../../shared/shared.module';
import { ActivatedRoute, Router } from '@angular/router';
import { patients } from '../../../dataDummy/patient';
import { formatData } from '../../../core/services/formatData.service';
import { HistoryExaminationComponent } from '../components/history-examination/history-examination.component';
import { PatientJourneyComponent } from '../components/patient-journey/patient-journey.component';

@Component({
  selector: 'app-examination-detail',
  imports: [sharedModule, HistoryExaminationComponent, PatientJourneyComponent],
  templateUrl: './examination-detail.component.html',
  styleUrl: './examination-detail.component.scss'
})
export class ExaminationDetailComponent implements OnInit {
  patientInfo: any;
  isShowPatientJourneyDialog: boolean = false;
  isShowHistoryDialog: boolean = false;


  constructor(
    public router: Router,
    public formatData: formatData,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.patientInfo = this.getPatientInfobyId(this.route.snapshot.params['id']);
    console.log("patient info", this.patientInfo);
    
  }

  getPatientInfobyId(id: any) {
    return patients.find((p: any) => p.id == id);
  }
}
