import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ExaminationRoutes } from './examination.routes';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    ExaminationRoutes
  ]
})
export class ExaminationModule { }
