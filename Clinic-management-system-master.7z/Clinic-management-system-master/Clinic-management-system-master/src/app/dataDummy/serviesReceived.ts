export const servicesReceived: any[] = [
    {
      id: 1,
      soPhieu: '1120',
      maDV: 'KB01',
      tenDV: 'Khám tổng thể',
      soLuong: 1,
      phongThucHien: 'P.103-Phòng khám',
      khoaChiDinh: 'Tiếp đón',
      bacSi: 'BS. Hồ Trọng Đại',
      thanhTien: '81.000'
    },
    {
      id: 2,
      soPhieu: '1120',
      maDV: 'KB02',
      tenDV: 'Khám nội',
      soLuong: 1,
      phongThucHien: 'P.101-Phòng khám nội',
      khoaChiDinh: 'Khám bệnh',
      bacSi: 'BS. Hồ Thị Loan',
      thanhTien: '81.000'
    },
    {
      id: 3,
      soPhieu: 'XN01',
      maDV: 'XN01',
      tenDV: 'Ure',
      soLuong: 1,
      phongThucHien: 'P.102-Phòng xét nghiệm',
      khoaChiDinh: 'Khám bệnh',
      bacSi: 'BS. Hồ Trung Hiếu',
      thanhTien: '81.000'
    }
  ]