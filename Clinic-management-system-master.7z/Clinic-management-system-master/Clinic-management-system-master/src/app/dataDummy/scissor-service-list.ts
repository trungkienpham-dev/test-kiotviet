export const SCISSOR_SERVICE_LIST = [
    {
        id: 1,
        name: 'Khâu vết thương loại 1'
    },
    {
        id: 2,
        name: 'Khâu vết thương loại 2'
    },
    {
        id: 3,
        name: 'Khâu vết thương'
    },
    {
        id: 4,
        name: 'Bó bột'
    },
    {
        id: 5,
        name: 'Tháo bột'
    },
    {
        id: 6,
        name: 'Hút mũi + rửa mũi'
    },
    {
        id: 7,
        name: 'Khí dung'
    },
    {
        id: 8,
        name: 'Lấy dị vật họng nông'
    },
    {
        id: 9,
        name: 'Lấy dị vật họng sâu'
    },
    {
        id: 10,
        name: 'Lấy ráy tai nội soi'
    }
];