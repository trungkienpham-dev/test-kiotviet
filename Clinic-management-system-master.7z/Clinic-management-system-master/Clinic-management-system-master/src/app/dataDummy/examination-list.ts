export const EXAMINATION_LIST = [
    {
        id: 1,
        name: 'Khám nội khoa',
    },
    {
        id: 2,
        name: 'Khám ngoại'
    },
    {
        id: 3,
        name: 'Khám nhi'
    },
    {
        id: 4,
        name: 'Khám thai và tư vấn'
    },
    {
        id: 5,
        name: 'Khám phụ khoa'
    },  
    {
        id: 6,
        name: 'Khám răng hàm mặt'
    },
    {
        id: 7,
        name: 'Khám mắt'
    },
    {
        id: 8,
        name: 'Khám tai mũi họng'
    },
    {
        id: 9,
        name: 'Khám cơ xương khớp'
    },
    {
        id: 10,
        name: 'Khám Lão khoa'
    },
    {
        id: 11,
        name: 'Khám Tim mạch nâng cao'
    },
    {
        id: 12,
        name: 'Khám Tâm lý và Sức khỏe tâm thần'
    },  
    {
        id: 13,
        name: 'Khám nội tiết – đái tháo đường'
    },
    {
        id: 14,
        name: 'Khám Hô hấp'
    },
];