import { Injectable } from '@angular/core';
import dayjs from 'dayjs';

@Injectable({
  providedIn: 'root',
})
export class formatData {
  getStatusTag(value: string) {
    switch (value.toLocaleLowerCase()) {
      case 'tiếp đón':
        return 'yellow';
      case 'chờ thanh toán':
        return 'orange';
      case 'chờ khám':
        return 'green';
      case 'đang khám':
        return 'blue';
      case 'đã khám':
        return 'red';
      default:
        return 'default'; // Màu mặc định của Ant Design
    }
  }

  formatGender(value: number) {
    return value === 1 ? 'Nam' : value === 0 ? 'Nữ' : 'Unknown';
  }

  formatDate(value: string) {
    return dayjs(value).isValid() ? dayjs(value).format('DD-MM-YYYY') : 'Invalid Date';
  }

  formatProperName(value: string) {
    return !value ? '' : value.toLowerCase().split(' ').map((word: string) => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
  }
}
