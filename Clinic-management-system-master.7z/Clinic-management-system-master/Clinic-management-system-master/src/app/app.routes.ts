import { Routes } from '@angular/router';
import { ContentLayoutComponent } from './layout/content-layout/content-layout.component';

export const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: '/home' },
  { path: 'home', component: ContentLayoutComponent, loadChildren: () => import('../app/modules/dashboard/dashboard.module').then(m => m.DashboardModule) },
  { path: 'reception', component: ContentLayoutComponent, loadChildren: () => import('../app/modules/reception/reception.module').then(m => m.ReceptionModule) },
  { path: 'examination', component: ContentLayoutComponent, loadChildren: () => import('../app/modules/examination/examination.module').then(m => m.ExaminationModule) },
  { path: 'payment', component: ContentLayoutComponent, loadChildren: () => import('../app/modules/payment/payment.module').then(m => m.PaymentModule) }
];
